<?php
/**
 * Plugin Name:         WC Minimum Order Value
 * Plugin URI:          https://zyonstudios.co.uk/plugins/
 * Description:         This simple plugin is developed for the users who dont like to deal with wordpress them codes.In this plugin you can simply input the value which you want customers to place as a minimum order
 * Version:             1.0.0
 * Requires at least:   5.2
 * Requires PHP:        7.2
 * Author:              zyonstudios
 * Author URI:          https://github.com/zyonstudios/wc-min-order-value/
 * Copyright:           zyonstudios
 * License:             GNU General Public License v3.0
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html 
 */

 if( !defined('ABSPATH')){
    exit;
 }
 use Carbon_Fields\Container;
 use Carbon_Fields\Field;
 
 add_action( 'carbon_fields_register_fields', 'zyon_wcminorder_value' );
 function zyon_wcminorder_value() {
     Container::make( 'theme_options', __( 'WC Minimum Order' ) )    
        ->set_icon( 'dashicons-cart' )
         ->add_fields( array(
             
             Field::make( 'text', 'zyon_wc_min_ord_val', 'WooCommerce Minimum Order Value' ),
              Field::make( 'html', 'zyn_wc_min_ord_val_information_text' )
                ->set_html( '<h2>Important : Enter the number value only without the currency code !</h2>' ),
             Field::make( 'radio', 'zyon_wc_min_ord_subtotal_total', 'Subtotal or Total cart value ?(Default=Total)' )
                ->add_options( array(
                     'total' => 'Total',
                    'subtotal' => 'Sub total',
                    ) )
         ) );
         
 }
 
 add_action( 'after_setup_theme', 'crb_load' );
 function crb_load() {
     require_once( 'vendor/autoload.php' );
     \Carbon_Fields\Carbon_Fields::boot();
 }

add_action( 'woocommerce_checkout_process', 'wc_minimum_order_amount' );
add_action( 'woocommerce_before_cart' , 'wc_minimum_order_amount' );
add_action( 'side-cart-woocommerce' , 'wc_minimum_order_amount' );
 
function wc_minimum_order_amount() {
    // Set this variable to specify a minimum order value
    $minimum = sanitize_text_field(carbon_get_theme_option('zyon_wc_min_ord_val'));   
    $cartvalue = sanitize_text_field(carbon_get_theme_option('zyon_wc_min_ord_subtotal_total'));   

    if ( WC()->cart->$cartvalue < $minimum ) {

        if( is_cart() ) {

            wc_print_notice( 
                sprintf( 'Your current order total is %s — you must have an order with a minimum of %s to place your order ' , 
                    wc_price( WC()->cart->$cartvalue ), 
                    wc_price( $minimum )
                ), 'error' 
            );

        } else {

            wc_add_notice( 
                sprintf( 'Your current order total is %s — you must have an order with a minimum of %s to place your order' , 
                    wc_price( WC()->cart->$cartvalue ), 
                    wc_price( $minimum )
                ), 'error' 
            );

        }
    }
}

//adding settings link
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'zyon_wcminorder_addactionlinks' );
    function zyon_wcminorder_addactionlinks ( $wcminorder_actions ) {
        $wcminorder_links = array(
        '<a href="' . admin_url( 'admin.php?page=crb_carbon_fields_container_wc_minimum_order.php' ) . '">Settings</a>',
        );
        $wcminorder_actions = array_merge( $wcminorder_actions, $wcminorder_links );
        return $wcminorder_actions;
 }
 

