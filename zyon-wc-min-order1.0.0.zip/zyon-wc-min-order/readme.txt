=== WC Minimum Order Value ===
Contributors: zyonstudios
Tags: woocommerce, cart, button,cart button text
Donate link: https://zyonstudios.co.uk/plugins/
Requires at least: 5.2
Tested up to: 6.1
Requires PHP: 7.2
Stable tag: 1.0.0
License: GNU General Public License v3.0
License URI: https://www.gnu.org/licenses/gpl.html

Set a minimum order value for your customers in WooCommerce store.
Requires WooCommerce plugin to be installed.

== Description ==
This is an simple plugin that Set a minimum order value for your customers in WooCommerce store.
Enter your minimum order value in number without the currency code.
Example for $40 minimum order enter just 40 in the input field.
Also Select if the minimum order value set for your subtotal or for the cart total.
Once you set the minimum order value customers will get the message on top of the cart page.


== Installation ==
1. Install via the Plugins screen in your WordPress dashboard, or download the ZIP, extract it, and upload to the `/wp-content/plugins/` directory.
2. Activate the plugin through the Plugins screen.
3. Go to Settings an Enter your minimum order value and save.

== Frequently Asked Questions ==
Will it work with my theme ?
It works as long as you have installed WooCommerce.

Where can I find the documentation ? 
Please visit https://www.zyonstudios.co.uk/plugins/


== Screenshots ==
1. Example access WC Minimum Order settings from the Wordpress dashboard menu.
2. Example of how it shows on cart page.

== Changelog ==
1.0.0
Release date 09 December 2022
* Initial release.